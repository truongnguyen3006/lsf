public class LsfKafkaAutoConfigurationTest {
}
