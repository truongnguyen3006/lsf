public class LsfKafkaAutoConfigurationTest {
}
