package com.myorg.lsf.outbox.postgres;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OutboxPublisherITApp {}